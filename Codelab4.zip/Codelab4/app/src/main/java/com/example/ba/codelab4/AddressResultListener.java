package com.example.ba.codelab4;

/**
 * @author Santiago Carrillo
 */
public interface AddressResultListener
{
    void onAddressFound( String address );
}
